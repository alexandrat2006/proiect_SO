# Raport utilizare instrumente- Etapa 1
**Student:** Alexandrat
### Descrierea interacțiunii
Am folosit cunostiintele invatate pentru la laborator logica de fișiere binare și gestionarea permisiunilor.
